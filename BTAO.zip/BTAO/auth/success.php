<?php
$ROOT_DIR="../";
$pageName = "Success";
include $ROOT_DIR . "user-templates/header.php";

?>

<div class="container">
  <center>
  <div class="card" style="width:50%;">
    <div class="card-header">
      Congratulations
    </div>
    <div class="card-body">
      You have successfully registered. Thank you. <br><br>
      <a href="../" class="btn btn-sm btn-primary">Done</a>
    </div>
  </div>
</center>
</div>




<?php include $ROOT_DIR . "user-templates/footer.php"; ?>
