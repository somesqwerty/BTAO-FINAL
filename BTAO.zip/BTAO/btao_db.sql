﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2023-11-29 04:13:35
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "account"
#

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "account"
#

INSERT INTO `account` VALUES (3,'admin','12','Admin','ADmin','Active','Admin',NULL),(4,'officer','12','John','Doe','Active','Officer',NULL),(5,'mike','339882','mikel','soms','Inactive','Staff',NULL),(6,'john','123','nny','somss','Active','Staff',NULL);

#
# Structure for table "contact"
#

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

#
# Data for table "contact"
#

INSERT INTO `contact` VALUES (1,'Mike','Soms',35),(2,'Ken','Est',16),(3,'john','sub',24);

#
# Structure for table "driver"
#

DROP TABLE IF EXISTS `driver`;
CREATE TABLE `driver` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `middleInitial` varchar(255) DEFAULT NULL,
  `address` text,
  `birthday` varchar(255) DEFAULT NULL,
  `licenseNumber` varchar(255) DEFAULT NULL,
  `plateNumber` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for table "driver"
#

INSERT INTO `driver` VALUES (2,'f','k','k','k','2023-12-31','kjj','jj','jj','jj','jjjhhs'),(3,'kenneth','estander','d','ca','2023-11-02','123123','123123','b','b','c'),(4,'mike','jor','f','gumamela','1000-10-10','1231','123123','3','d','a'),(5,'huy','huy','h','hauy','1231-12-17','12','123123','b','b','b');

#
# Structure for table "driver_penalty"
#

DROP TABLE IF EXISTS `driver_penalty`;
CREATE TABLE `driver_penalty` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `dateAdded` date DEFAULT NULL,
  `officerId` int(11) DEFAULT NULL,
  `driverId` int(11) DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending',
  `zoneId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

#
# Data for table "driver_penalty"
#

INSERT INTO `driver_penalty` VALUES (1,'2023-11-29',4,3,'Pending',2);

#
# Structure for table "penalty_item"
#

DROP TABLE IF EXISTS `penalty_item`;
CREATE TABLE `penalty_item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `violationId` int(11) DEFAULT NULL,
  `driverPenaltyId` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

#
# Data for table "penalty_item"
#

INSERT INTO `penalty_item` VALUES (1,7,1,NULL,'2023-11-29'),(2,4,1,NULL,'2023-11-29'),(3,4,1,NULL,'2023-11-29');

#
# Structure for table "violation"
#

DROP TABLE IF EXISTS `violation`;
CREATE TABLE `violation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# Data for table "violation"
#

INSERT INTO `violation` VALUES (2,'Illegal Parking',1000),(3,'no helmet',200),(4,'obstruction',300),(5,'reckless',300),(6,'no seatbelt',300),(7,'no license',1500),(8,'improper attire',1),(9,'qq',100);

#
# Structure for table "zone"
#

DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "zone"
#

INSERT INTO `zone` VALUES (2,'bangas'),(3,'zone 1'),(4,'zone 2'),(5,'zone 3');
