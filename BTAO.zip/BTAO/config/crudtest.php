<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header-blank.php";
?>


sdfklsdjfsdlkfj
